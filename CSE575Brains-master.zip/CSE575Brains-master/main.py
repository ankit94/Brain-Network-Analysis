import numpy as np
from model import ClassifierModel, RegressionModel

#extract data from pkl and then use the models from model.py to do the stuff